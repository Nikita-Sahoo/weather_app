// Configuration file that loads environment variables
const CONFIG = {
    WEATHER_API_KEY: '494985f9106bee9b64a897e2ebd440cd',
    BASE_URL: 'https://api.openweathermap.org/data/2.5'
};